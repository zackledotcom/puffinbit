import React from 'react'
import EnhancedFileDemo from './chat/EnhancedFileDemo'

export default function EnhancedFileDemoPage() {
  return <EnhancedFileDemo />
}
