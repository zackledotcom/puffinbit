#!/usr/bin/env node

/**
 * PHASE 1 FIX - Implementation Verification Script
 * 
 * This script verifies that all Phase 1 fixes have been properly implemented:
 * 1. IPC handlers registered
 * 2. Validation schemas created  
 * 3. Error boundaries added
 * 4. Safety checks implemented
 */

const fs = require('fs');
const path = require('path');

console.log('🔧 PHASE 1 IMPLEMENTATION VERIFICATION');
console.log('=====================================\n');

const projectRoot = path.resolve(__dirname, '..');
let allChecksPass = true;

function checkFile(filePath, description) {
  const fullPath = path.join(projectRoot, filePath);
  const exists = fs.existsSync(fullPath);
  console.log(`${exists ? '✅' : '❌'} ${description}: ${filePath}`);
  if (!exists) allChecksPass = false;
  return exists;
}

function checkFileContent(filePath, searchText, description) {
  const fullPath = path.join(projectRoot, filePath);
  try {
    const content = fs.readFileSync(fullPath, 'utf8');
    const contains = content.includes(searchText);
    console.log(`${contains ? '✅' : '❌'} ${description}`);
    if (!contains) allChecksPass = false;
    return contains;
  } catch (error) {
    console.log(`❌ ${description} - File not found`);
    allChecksPass = false;
    return false;
  }
}

console.log('📁 FILE STRUCTURE VERIFICATION');
console.log('-------------------------------');

// Check critical files exist
checkFile('src/shared/validation.ts', 'Validation schemas');
checkFile('src/main/__tests__/ipc-handlers.test.ts', 'IPC integration tests');
checkFile('src/preload/index.ts', 'Preload IPC bridge');
checkFile('src/main/index.ts', 'Main process handlers');
checkFile('src/renderer/src/App.tsx', 'Renderer with safety checks');

console.log('\n🔧 IPC HANDLER VERIFICATION');
console.log('----------------------------');

// Check IPC handlers are registered
checkFileContent('src/main/index.ts', 'check-ollama-status', 'Ollama status handler registered');
checkFileContent('src/main/index.ts', 'start-ollama', 'Ollama start handler registered');
checkFileContent('src/main/index.ts', 'get-ollama-models', 'Get models handler registered');
checkFileContent('src/main/index.ts', 'pull-model', 'Pull model handler registered');
checkFileContent('src/main/index.ts', 'delete-model', 'Delete model handler registered');
checkFileContent('src/main/index.ts', 'check-chroma-status', 'ChromaDB status handler registered');
checkFileContent('src/main/index.ts', 'start-chroma', 'ChromaDB start handler registered');
checkFileContent('src/main/index.ts', 'chat-with-ai', 'Chat handler registered');

console.log('\n🛡️ VALIDATION & SECURITY VERIFICATION');
console.log('-------------------------------------');

// Check validation is implemented
checkFileContent('src/shared/validation.ts', 'ChatRequestSchema', 'Chat request validation schema');
checkFileContent('src/shared/validation.ts', 'ModelNameSchema', 'Model name validation schema');
checkFileContent('src/shared/validation.ts', 'validateChatRequest', 'Chat validation function');
checkFileContent('src/main/index.ts', 'validateChatRequest', 'Validation used in handlers');
checkFileContent('src/main/index.ts', 'validateModelName', 'Model name validation used');

console.log('\n🔒 SAFETY & ERROR HANDLING VERIFICATION');
console.log('---------------------------------------');

// Check safety measures
checkFileContent('src/renderer/src/App.tsx', 'PHASE 1 FIX', 'App component safety updates');
checkFileContent('src/renderer/src/App.tsx', 'apiReady', 'API readiness check');
checkFileContent('src/renderer/src/App.tsx', 'window.api', 'Window API safety check');
checkFileContent('src/preload/index.ts', 'createSafeIPCHandler', 'Safe IPC wrapper');
checkFileContent('src/preload/index.ts', 'timeout', 'IPC timeout handling');

console.log('\n🧪 TEST VERIFICATION');
console.log('--------------------');

// Check test files
checkFileContent('src/main/__tests__/ipc-handlers.test.ts', 'validateChatRequest', 'Validation tests');
checkFileContent('src/main/__tests__/ipc-handlers.test.ts', 'IPC Handler Integration', 'IPC integration tests');

console.log('\n📊 WHITELIST VERIFICATION');
console.log('-------------------------');

// Check IPC whitelist updated
checkFileContent('src/main/index.ts', 'check-ollama-status', 'Ollama status in whitelist');
checkFileContent('src/main/index.ts', 'chat-with-ai', 'Chat handler in whitelist');

console.log('\n🎯 SUMMARY');
console.log('----------');

if (allChecksPass) {
  console.log('✅ ALL PHASE 1 FIXES IMPLEMENTED SUCCESSFULLY!');
  console.log('');
  console.log('🚀 READY TO TEST:');
  console.log('1. Run: npm run dev');
  console.log('2. Check browser console for IPC connection logs');
  console.log('3. Test basic chat functionality');
  console.log('4. Verify model loading works');
  console.log('5. Check service status indicators');
  console.log('');
  console.log('📈 NEXT STEPS:');
  console.log('- Run integration tests: npm test');
  console.log('- Test on M1 MacBook for CPU performance');
  console.log('- Monitor error logs during usage');
  process.exit(0);
} else {
  console.log('❌ SOME PHASE 1 FIXES ARE MISSING OR INCOMPLETE');
  console.log('');
  console.log('🔧 ACTION REQUIRED:');
  console.log('- Review the failed checks above');
  console.log('- Ensure all files have been properly updated');
  console.log('- Re-run this verification script after fixes');
  process.exit(1);
}
